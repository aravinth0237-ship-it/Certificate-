(() => {
  const records = window.CERTIFICATE_RECORDS || [];
  const portalName = window.PORTAL_NAME || "Certificate Portal";
  document.querySelectorAll("#siteName").forEach(el => el.textContent = portalName.toUpperCase());
  document.querySelectorAll("#footerName").forEach(el => el.textContent = portalName);
  document.querySelectorAll("#year").forEach(el => el.textContent = new Date().getFullYear());

  const result = document.getElementById("result");
  const codeInput = document.getElementById("code");
  const clean = value => String(value || "").trim().toUpperCase();

  function showRecord(code) {
    if (!result) return;
    const record = records.find(item => clean(item.code) === clean(code));
    result.hidden = false;
    if (!record) {
      result.innerHTML = `<div class="invalid"><strong>Certificate not found</strong>No matching record was found for code <b>${escapeHtml(code)}</b>. Check the code and try again.</div>`;
      return;
    }
    result.innerHTML = `
      <div class="result-card">
        <div class="result-head"><span>✓</span> Certificate record found</div>
        <div class="result-body">
          <div class="status">● ${escapeHtml(record.status || "Valid").toUpperCase()}</div>
          <h2>${escapeHtml(record.name)}</h2>
          <div class="details">
            ${field("VERIFICATION CODE", record.code)}
            ${field("COURSE / PROGRAM", record.course)}
            ${field("ISSUING ORGANIZATION", record.institution)}
            ${field("DATE OF ISSUE", record.issueDate)}
          </div>
        </div>
      </div>`;
  }
  function field(label, value) {
    return `<div class="detail"><label>${label}</label><div>${escapeHtml(value || "—")}</div></div>`;
  }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  }

  const form = document.getElementById("verifyForm");
  if (form) form.addEventListener("submit", event => {
    event.preventDefault();
    const code = codeInput.value.trim();
    if (code) {
      history.pushState({}, "", `/verify/${encodeURIComponent(code)}`);
      showRecord(code);
    }
  });

  const match = location.pathname.match(/^\/verify\/(.+)\/?$/i);
  if (match) showRecord(decodeURIComponent(match[1]));
})();
