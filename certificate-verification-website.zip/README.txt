CERTIFICATE VERIFICATION WEBSITE
=================================

WHAT THIS ZIP CONTAINS
- A responsive certificate verification website.
- URL pattern: https://YOUR-SITE.pages.dev/verify/CERT-2026-001
- Editable website/organization name.
- Editable sample certificate records.

CUSTOMIZE BEFORE PUBLISHING
1. Open records.js.
2. Change PORTAL_NAME to your own organization/site name.
3. Replace the sample records with real records you are authorized to publish.
4. Each record needs a unique code, name, course, institution, issueDate and status.
5. Save the file.

DEPLOY TO CLOUDFLARE PAGES
1. Extract this ZIP.
2. Sign in at https://dash.cloudflare.com/
3. Open Workers & Pages -> Create -> Pages -> Upload assets (Direct Upload).
4. Upload the extracted project folder (not the ZIP, if the dashboard asks for files).
5. Choose a project name. Your initial URL will be:
   https://PROJECT-NAME.pages.dev
6. To use a URL path, visit:
   https://PROJECT-NAME.pages.dev/verify/CERT-2026-001

CUSTOM DOMAIN
In the Pages project, open Custom domains and add a domain you own.
You cannot use another organization's domain (for example, nptel.ac.in).
The .pages.dev suffix cannot be renamed, but the project subdomain can be selected
when creating the project. A custom domain requires domain registration.

IMPORTANT
This is a demo template, not an official NPTEL website or certificate database.
It does not verify certificates against an external institution. It only looks up
records you add to records.js. Do not publish private personal information or
claim a certificate is authentic unless you have independently verified it.
