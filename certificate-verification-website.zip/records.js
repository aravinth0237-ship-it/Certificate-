// Edit this file to add your own certificate records.
// The code in the URL must match the "code" value exactly (case-insensitive).
window.CERTIFICATE_RECORDS = [
  {
    code: "CERT-2026-001",
    name: "Sample Student",
    course: "Introduction to Web Development",
    institution: "Example Learning Institute",
    issueDate: "11 November 2026",
    status: "Valid"
  },
  {
    code: "CERT-2026-002",
    name: "Demo Candidate",
    course: "Fundamentals of Data Science",
    institution: "Example Learning Institute",
    issueDate: "10 November 2026",
    status: "Valid"
  }
];

// Change this to your own website/organization display name.
window.PORTAL_NAME = "CERTIFICATE PORTAL";
